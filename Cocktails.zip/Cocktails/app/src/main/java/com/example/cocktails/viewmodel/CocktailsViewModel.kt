package com.example.cocktails.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cocktails.model.CocktailModel
import com.example.cocktails.network.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CocktailsViewModel @Inject constructor(repository: Repository):ViewModel() {
    private val _mutableCocktails = MutableLiveData<List<CocktailModel>>()
    val cocktails: LiveData<List<CocktailModel>>
        get()=_mutableCocktails

    init {
        viewModelScope.launch {
            try {
                _mutableCocktails.value = repository.loadCocktails("a")
            }
            catch (e:Exception)
            {
                
            }
        }
    }
}