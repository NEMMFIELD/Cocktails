package com.example.cocktails.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cocktails.R
import com.example.cocktails.adapter.CocktailsAdapter
import com.example.cocktails.databinding.FragmentCocktailsBinding
import com.example.cocktails.viewmodel.CocktailsViewModel


class FragmentCocktails : Fragment() {
    private var _binding:FragmentCocktailsBinding? = null
    private val binding get() = _binding
    private lateinit var adapter: CocktailsAdapter
    private val viewModel:CocktailsViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       _binding = FragmentCocktailsBinding.inflate(inflater,container,false)
        val view = binding?.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initRecyclerView()
    }

    private fun initRecyclerView() = with(binding)
    {
        this?.recycler?.layoutManager = GridLayoutManager(context,2)
        adapter = CocktailsAdapter()
        this?.recycler?.adapter = adapter
        adapter.submitList(viewModel.cocktails.value)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentCocktails.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentCocktails().apply {
                arguments = Bundle().apply {
                   // putString(ARG_PARAM1, param1)
                    //putString(ARG_PARAM2, param2)
                }
            }
    }
}