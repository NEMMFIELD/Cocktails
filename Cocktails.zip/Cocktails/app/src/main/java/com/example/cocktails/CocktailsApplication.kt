package com.example.cocktails

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CocktailsApplication:Application()