package com.example.cocktails.network

import com.example.cocktails.model.CocktailModel
import com.example.cocktails.model.Response
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

interface IRepository {
    suspend fun loadRandomCocktail(): CocktailModel
    suspend fun loadCocktails(param: String): List<CocktailModel>
}

class Repository @Inject constructor(private val cocktailsApi: CocktailsApi) : IRepository {
    override suspend fun loadRandomCocktail(): CocktailModel =
        withContext(Dispatchers.IO) { convertResponseToModel(cocktailsApi.getRandomCocktail()) }

    override suspend fun loadCocktails(param: String): List<CocktailModel> =
        withContext(Dispatchers.IO)
        {
            listOf(convertResponseToModel(cocktailsApi.getCocktailsByFirstLetter(param)))
        }

    private fun convertResponseToModel(response: Response): CocktailModel =
        CocktailModel(
            id = response.drinks?.get(0)?.idDrink,
            name = response.drinks?.get(0)?.strDrink,
            imgPath = response.drinks?.get(0)?.strDrinkThumb.toString()
        )
}