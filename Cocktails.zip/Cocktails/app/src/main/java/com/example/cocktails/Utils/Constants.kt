package com.example.cocktails.Utils

object Constants {
    const val BASE_URL = "https://www.thecocktaildb.com/api/json/v1/"
}